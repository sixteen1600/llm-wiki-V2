# _shared.ps1
# 共用函式：供 scripts/ 底下其他 PowerShell 腳本呼叫。
# 執行位置：建議在 internship_llm_wiki 專案根目錄執行各腳本。
# 設計原則：不直接綁定特定 Codex CLI；產生可貼給 Codex 的 request markdown。

Set-StrictMode -Version Latest

function Get-WikiProjectRoot {
    return (Split-Path -Parent $PSScriptRoot)
}

function Resolve-WikiPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Root
    )

    if ([System.IO.Path]::IsPathRooted($Path)) {
        return $Path
    }

    return (Join-Path $Root $Path)
}

function Convert-ToProjectRelativePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Root
    )

    try {
        $resolvedPath = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
        $resolvedRoot = (Resolve-Path -LiteralPath $Root -ErrorAction Stop).Path

        if ($resolvedPath.StartsWith($resolvedRoot)) {
            return $resolvedPath.Substring($resolvedRoot.Length).TrimStart("\", "/")
        }

        return $resolvedPath
    } catch {
        return $Path
    }
}

function New-CodexRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskName,

        [Parameter(Mandatory = $true)]
        [string]$PromptRelativePath,

        [string[]]$SourcePaths = @(),

        [string]$ExtraInstruction = "",

        [switch]$NoClipboard,

        [switch]$Open
    )

    $Root = Get-WikiProjectRoot
    $PromptPath = Join-Path $Root $PromptRelativePath

    if (-not (Test-Path -LiteralPath $PromptPath)) {
        throw "Prompt file not found: $PromptRelativePath"
    }

    $RequestDir = Join-Path $Root ".codex_requests"
    if (-not (Test-Path -LiteralPath $RequestDir)) {
        New-Item -ItemType Directory -Path $RequestDir | Out-Null
    }

    $PromptText = Get-Content -LiteralPath $PromptPath -Raw -Encoding UTF8

    $Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $SafeTaskName = $TaskName -replace "[^\w\-]", "_"
    $OutputPath = Join-Path $RequestDir "$Timestamp`_$SafeTaskName.md"

    $SourceLines = New-Object System.Collections.Generic.List[string]
    foreach ($Source in $SourcePaths) {
        if ([string]::IsNullOrWhiteSpace($Source)) {
            continue
        }

        $FullPath = Resolve-WikiPath -Path $Source -Root $Root
        $Relative = Convert-ToProjectRelativePath -Path $FullPath -Root $Root

        if (Test-Path -LiteralPath $FullPath) {
            $SourceLines.Add("- `$Relative`")
        } else {
            $SourceLines.Add("- `$Source` (not found yet or needs review)")
        }
    }

    if ($SourceLines.Count -eq 0) {
        $SourceSection = "- No source path provided. Use the instruction below and ask the user for the missing source if needed."
    } else {
        $SourceSection = ($SourceLines -join [Environment]::NewLine)
    }

    $Request = @"
# Codex Request - $TaskName

請在 `internship_llm_wiki` 專案根目錄執行本任務。

## 1. 使用的 Prompt

- `$PromptRelativePath`

## 2. 來源檔案或資料夾

$SourceSection

## 3. 額外指示

$ExtraInstruction

## 4. 執行規則

- 嚴格遵守下方 prompt。
- 只能依據專案內既有檔案與使用者提供的來源處理。
- 不要自行新增未定稿的資料夾或 index。
- 不要保存客戶資料、保單資料、API Key、Token、完整內部系統網址、未遮蔽截圖或未抽象化內部流程。
- 若遇到不確定內容，標記為 `needs_review`，不要寫成已確認事實。
- 完成後，請回報建立或修改了哪些檔案。

---

# Prompt Content

```markdown
$PromptText
```
"@

    Set-Content -LiteralPath $OutputPath -Value $Request -Encoding UTF8

    if (-not $NoClipboard) {
        try {
            Set-Clipboard -Value $Request
            Write-Host "Request copied to clipboard."
        } catch {
            Write-Warning "Unable to copy request to clipboard. The request file was still created."
        }
    }

    if ($Open) {
        Invoke-Item -LiteralPath $OutputPath
    }

    Write-Host ""
    Write-Host "Codex request created:"
    Write-Host $OutputPath
    Write-Host ""
    Write-Host "Next step:"
    Write-Host "1. Open Codex Desktop in the project root."
    Write-Host "2. Paste the generated request, or open the request file above."
    Write-Host "3. Let Codex apply the requested changes."
}
