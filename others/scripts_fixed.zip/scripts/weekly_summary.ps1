# weekly_summary.ps1
# 對應 prompt：prompts/05_generate_weekly_summary.md
# 用途：建立「產生 weekly summary」的 Codex request。

param(
    [string]$Week = "",

    [string]$DateRange = "",

    [string[]]$DailyLogs = @(),

    [string[]]$MeetingNotes = @(),

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$Sources = @()
$Sources += $DailyLogs
$Sources += $MeetingNotes

$DailyText = if ($DailyLogs.Count -gt 0) { ($DailyLogs -join ", ") } else { "未指定，請 Codex 依 week/date_range 從 logs/daily/ 判斷" }
$MeetingText = if ($MeetingNotes.Count -gt 0) { ($MeetingNotes -join ", ") } else { "未指定或無" }

$Extra = @"
請依照 `prompts/05_generate_weekly_summary.md` 產生 weekly summary。

要求：
- 週次：$Week
- 日期範圍：$DateRange
- daily logs：$DailyText
- meeting notes：$MeetingText
- 輸出到 `logs/weekly/`
- 不建立正式 wiki 筆記
- 不更新 indexes
- 若有新 wiki 候選項目，只列出候選，不直接建立
"@

New-CodexRequest `
    -TaskName "05_generate_weekly_summary" `
    -PromptRelativePath "prompts/05_generate_weekly_summary.md" `
    -SourcePaths $Sources `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
