# extract_wiki.ps1
# 對應 prompt：prompts/03_extract_wiki_notes.md
# 用途：建立「由 daily log / meeting / weekly / monthly 萃取 wiki 筆記」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string[]]$Sources,

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$SourceText = ($Sources -join ", ")

$Extra = @"
請依照 `prompts/03_extract_wiki_notes.md` 從來源紀錄萃取正式 wiki 筆記。

要求：
- 來源：$SourceText
- 可處理 `logs/daily/`、`logs/meetings/`、`logs/weekly/`、`logs/monthly/`
- 建立或更新對應 `wiki/` 筆記
- 每份 wiki 筆記必須包含 metadata、來源追蹤、敏感資訊檢查與 Knowledge Graph 關聯區塊
- 不更新 indexes
- 不新增固定資料夾
- 不補充來源沒有出現的外部知識
"@

New-CodexRequest `
    -TaskName "03_extract_wiki_notes" `
    -PromptRelativePath "prompts/03_extract_wiki_notes.md" `
    -SourcePaths $Sources `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
