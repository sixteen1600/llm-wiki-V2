# generate_daily.ps1
# 對應 prompt：prompts/02_generate_daily_log.md
# 用途：建立「由 raw note 產生 daily log」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string[]]$RawNotes,

    [string]$Date = "",

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$RawNoteText = ($RawNotes -join ", ")

$Extra = @"
請依照 `prompts/02_generate_daily_log.md` 從 raw note 產生 daily log。

要求：
- 來源 raw note：$RawNoteText
- 若使用者提供日期，使用此日期：$Date
- 輸出到 `logs/daily/YYYY-MM-DD.md`
- 只產生 daily log
- 不建立正式 wiki 筆記
- 不更新 indexes
- 敏感資訊只做初步檢查與抽象化
"@

New-CodexRequest `
    -TaskName "02_generate_daily_log" `
    -PromptRelativePath "prompts/02_generate_daily_log.md" `
    -SourcePaths $RawNotes `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
