# scripts/

本資料夾保存實習 LLM Wiki 的 PowerShell 自動化腳本。

這些腳本的定位不是直接取代 Codex，而是幫你：

1. 讀取對應的 `prompts/`
2. 整理來源檔案路徑與任務要求
3. 產生一份可貼給 Codex 的 request markdown
4. 自動複製到剪貼簿
5. 儲存到 `.codex_requests/`

這樣可以避免把腳本綁死在特定 Codex CLI 或桌面版操作方式上。

---

## 1. 使用前提

請在專案根目錄執行腳本：

```powershell
cd path\to\internship_llm_wiki
```

例如：

```powershell
.\scripts\generate_daily.ps1 -RawNotes "raw/imported_notes/2026/2026_07_03_Fri.md" -Open
```

腳本會產生：

```text
.codex_requests/YYYYMMDD_HHMMSS_task_name.md
```

並將內容複製到剪貼簿。

---

## 2. 腳本列表

| 腳本 | 對應 Prompt | 用途 |
|---|---|---|
| `import_note.ps1` | `01_import_raw_note.md` | 匯入原始筆記 |
| `generate_daily.ps1` | `02_generate_daily_log.md` | 從 raw note 產生 daily log |
| `extract_wiki.ps1` | `03_extract_wiki_notes.md` | 從 log 萃取正式 wiki 筆記 |
| `update_indexes.ps1` | `04_update_indexes.md` | 更新 indexes |
| `weekly_summary.ps1` | `05_generate_weekly_summary.md` | 產生 weekly summary |
| `monthly_review.ps1` | `06_generate_monthly_review.md` | 產生 monthly review |
| `meeting_note.ps1` | `07_process_meeting_note.md` | 整理 meeting note |
| `sensitive_review.ps1` | `08_sensitive_info_review.md` | 敏感資訊審查 |
| `_shared.ps1` | 共用函式 | 不直接執行 |

---

## 3. 常用指令

### 3.1 匯入原始筆記

```powershell
.\scripts\import_note.ps1 `
  -Source "raw/inbox/2026_07_03_Fri.md" `
  -Date "2026-07-03" `
  -Open
```

### 3.2 產生 daily log

```powershell
.\scripts\generate_daily.ps1 `
  -RawNotes "raw/imported_notes/2026/2026_07_03_Fri.md" `
  -Date "2026-07-03" `
  -Open
```

### 3.3 萃取 wiki 筆記

```powershell
.\scripts\extract_wiki.ps1 `
  -Sources "logs/daily/2026-07-03.md" `
  -Open
```

### 3.4 更新 indexes

```powershell
.\scripts\update_indexes.ps1 `
  -Sources "logs/daily/2026-07-03.md", "wiki/tools/google_adk.md" `
  -UpdateHome `
  -Open
```

### 3.5 整理會議筆記

```powershell
.\scripts\meeting_note.ps1 `
  -Source "raw/imported_notes/2026/2026_07_03_Fri.md" `
  -Date "2026-07-03" `
  -Topic "google_adk_report_discussion" `
  -Open
```

### 3.6 敏感資訊審查

Review Only：

```powershell
.\scripts\sensitive_review.ps1 `
  -Targets "logs/daily/2026-07-03.md" `
  -Mode ReviewOnly `
  -Open
```

Review and Patch：

```powershell
.\scripts\sensitive_review.ps1 `
  -Targets "logs/daily/2026-07-03.md" `
  -Mode ReviewAndPatch `
  -Open
```

### 3.7 產生 weekly summary

```powershell
.\scripts\weekly_summary.ps1 `
  -Week "2026-W27" `
  -DateRange "2026-06-29 to 2026-07-03" `
  -DailyLogs "logs/daily/2026-07-01.md", "logs/daily/2026-07-02.md", "logs/daily/2026-07-03.md" `
  -Open
```

### 3.8 產生 monthly review

```powershell
.\scripts\monthly_review.ps1 `
  -Month "2026-07" `
  -WeeklySummaries "logs/weekly/2026-W27.md", "logs/weekly/2026-W28.md" `
  -Open
```

---

## 4. 建議每日工作流

```powershell
.\scripts\import_note.ps1 -Source "raw/inbox/YYYY_MM_DD_Ddd.md" -Date "YYYY-MM-DD" -Open
```

將 request 貼給 Codex，確認匯入完成後，再執行：

```powershell
.\scripts\generate_daily.ps1 -RawNotes "raw/imported_notes/YYYY/YYYY_MM_DD_Ddd.md" -Date "YYYY-MM-DD" -Open
```

daily log 完成後：

```powershell
.\scripts\extract_wiki.ps1 -Sources "logs/daily/YYYY-MM-DD.md" -Open
```

wiki 筆記完成後：

```powershell
.\scripts\update_indexes.ps1 -Sources "logs/daily/YYYY-MM-DD.md" -UpdateHome -Open
```

---

## 5. 注意事項

- 腳本不會直接呼叫 Codex CLI。
- 腳本不會直接修改 `raw/`、`logs/`、`wiki/` 或 `indexes/`。
- 腳本只產生 Codex request。
- 真正的檔案修改由 Codex 根據 request 執行。
- `.codex_requests/` 是執行時產物，可視需要加入 `.gitignore`。
