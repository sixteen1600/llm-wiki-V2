# monthly_review.ps1
# 對應 prompt：prompts/06_generate_monthly_review.md
# 用途：建立「產生 monthly review」的 Codex request。

param(
    [string]$Month = "",

    [string]$DateRange = "",

    [string[]]$WeeklySummaries = @(),

    [string[]]$DailyLogs = @(),

    [string[]]$MeetingNotes = @(),

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$Sources = @()
$Sources += $WeeklySummaries
$Sources += $DailyLogs
$Sources += $MeetingNotes

$WeeklyText = if ($WeeklySummaries.Count -gt 0) { ($WeeklySummaries -join ", ") } else { "未指定，請 Codex 依 month/date_range 從 logs/weekly/ 判斷" }
$DailyText = if ($DailyLogs.Count -gt 0) { ($DailyLogs -join ", ") } else { "未指定或無" }
$MeetingText = if ($MeetingNotes.Count -gt 0) { ($MeetingNotes -join ", ") } else { "未指定或無" }

$Extra = @"
請依照 `prompts/06_generate_monthly_review.md` 產生 monthly review。

要求：
- 月份：$Month
- 日期範圍：$DateRange
- weekly summaries：$WeeklyText
- daily logs：$DailyText
- meeting notes：$MeetingText
- 輸出到 `logs/monthly/`
- 不建立正式 wiki 筆記
- 不更新 indexes
- 若有新 wiki 候選項目，只列出候選，不直接建立
"@

New-CodexRequest `
    -TaskName "06_generate_monthly_review" `
    -PromptRelativePath "prompts/06_generate_monthly_review.md" `
    -SourcePaths $Sources `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
