# sensitive_review.ps1
# 對應 prompt：prompts/08_sensitive_info_review.md
# 用途：建立「敏感資訊審查」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string[]]$Targets,

    [ValidateSet("ReviewOnly", "ReviewAndPatch")]
    [string]$Mode = "ReviewOnly",

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$TargetText = ($Targets -join ", ")

$ModeInstruction = if ($Mode -eq "ReviewAndPatch") {
    "使用 Review and Patch 模式：可直接修正檔案，但不得刪除原始檔案，且不得改變原始學習語意。"
} else {
    "使用 Review Only 模式：只回報風險與修改建議，不直接修改檔案。"
}

$Extra = @"
請依照 `prompts/08_sensitive_info_review.md` 進行敏感資訊審查。

要求：
- 審查目標：$TargetText
- 模式：$Mode
- $ModeInstruction
- 檢查 raw / logs / wiki / indexes 是否包含敏感資訊
- 不複製敏感資訊原文到回覆
- 必須提供風險等級、建議處理與 metadata 建議
"@

New-CodexRequest `
    -TaskName "08_sensitive_info_review" `
    -PromptRelativePath "prompts/08_sensitive_info_review.md" `
    -SourcePaths $Targets `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
