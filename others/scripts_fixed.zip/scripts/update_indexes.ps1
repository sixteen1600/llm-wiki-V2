# update_indexes.ps1
# 對應 prompt：prompts/04_update_indexes.md
# 用途：建立「根據 wiki / logs 更新 indexes」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string[]]$Sources,

    [switch]$UpdateHome,

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$SourceText = ($Sources -join ", ")
$HomeText = if ($UpdateHome) { "需要評估是否同步更新 `indexes/home.md`。" } else { "除非明確必要，不更新 `indexes/home.md`。" }

$Extra = @"
請依照 `prompts/04_update_indexes.md` 更新 indexes。

要求：
- 來源：$SourceText
- 只允許更新既有 12 個 indexes
- 不建立新的 index
- 不建立 wiki 筆記
- 不建立 Knowledge Graph index
- 不把完整 wiki 內容複製進 index
- $HomeText
"@

New-CodexRequest `
    -TaskName "04_update_indexes" `
    -PromptRelativePath "prompts/04_update_indexes.md" `
    -SourcePaths $Sources `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
