# import_note.ps1
# 對應 prompt：prompts/01_import_raw_note.md
# 用途：建立「匯入原始筆記」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string]$Source,

    [string]$Date = "",

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$Extra = @"
請依照 `prompts/01_import_raw_note.md` 匯入指定 raw note。

要求：
- 來源：$Source
- 若使用者提供日期，使用此日期：$Date
- 將匯入結果放到 `raw/imported_notes/`
- 保留原始內容，不產生 daily log，不建立 wiki，不更新 indexes
- 若有疑似敏感資訊，只標記 `sensitive_review_status: needs_review`
"@

New-CodexRequest `
    -TaskName "01_import_raw_note" `
    -PromptRelativePath "prompts/01_import_raw_note.md" `
    -SourcePaths @($Source) `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
