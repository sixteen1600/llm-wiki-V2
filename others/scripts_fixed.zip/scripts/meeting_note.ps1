# meeting_note.ps1
# 對應 prompt：prompts/07_process_meeting_note.md
# 用途：建立「整理 meeting note」的 Codex request。

param(
    [Parameter(Mandatory = $true)]
    [string]$Source,

    [string]$Date = "",

    [string]$Topic = "",

    [switch]$NoClipboard,

    [switch]$Open
)

. (Join-Path $PSScriptRoot "_shared.ps1")

$Extra = @"
請依照 `prompts/07_process_meeting_note.md` 整理會議筆記。

要求：
- 來源：$Source
- 日期：$Date
- 會議主題：$Topic
- 輸出到 `logs/meetings/`
- 只整理 meeting note
- 不建立正式 wiki 筆記
- 不更新 indexes
- 若內容可能敏感，先抽象化並標記 `sensitive_review_status: needs_review`
"@

New-CodexRequest `
    -TaskName "07_process_meeting_note" `
    -PromptRelativePath "prompts/07_process_meeting_note.md" `
    -SourcePaths @($Source) `
    -ExtraInstruction $Extra `
    -NoClipboard:$NoClipboard `
    -Open:$Open
