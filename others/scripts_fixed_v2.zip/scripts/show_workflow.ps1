[CmdletBinding()]
param()

$workflow = @(
    "1. import_note.ps1",
    "2. sensitive_review.ps1",
    "3. generate_daily.ps1",
    "4. meeting_note.ps1, when the source is a meeting note",
    "5. extract_wiki.ps1",
    "6. update_indexes.ps1",
    "7. weekly_summary.ps1",
    "8. monthly_review.ps1"
)

Write-Host "Recommended workflow:"
foreach ($item in $workflow) {
    Write-Host $item
}
